library(tidyverse)
library(sf)


#special note on the HERE R package.
#it defaults to add the calculation of tolls, which is makes the api cost $5 per 1,000
#With the package loaded run:

#trace("route", edit=TRUE)

#And remove the following part of the function in the editor window:
  
  # Add tolls (note: has to be added after &return=...)
 # if (transport_mode %in% c("car", "truck", "taxi", "bus")) {
#    url <- paste0(
#      url,
#      ifelse(
#        vignettes,
#        ",tolls&tolls[summaries]=total&currency=",
#        ",tolls&tolls[summaries]=total&tolls[vignettes]=all&currency="
#      ),
#      .get_currency()
#    )
#  }

#this way you can safely stay under the free tier for passenger vehicle routing

library(hereR)

setwd("C:/Users/aeckerson/Documents/projects/mo_crossings_part_2/")
#Here API key 
hereR::set_key("eLgtGQJr5wgrN7DXLjLZqTfeGHEIdcdM2uRVX7Bji_4")
#clear environment
rm(list = ls())


#reading lines paths of base ods
moves <- st_read("data/crossing_movements.shp") %>% 
  #remove where there is no alternative path or rail location is missing per annotations
  filter(!Note %in% c("No Alt", "No rail", "No Routing")) %>% 
  select(CrossingId)

moves$eu_distance <- st_length(moves) %>% as.numeric() * 0.3048
moves_straight_distance <- moves %>% st_drop_geometry()

moves <- moves %>% 
  select(-eu_distance) %>% 
  st_transform(4326)

#getting the number of rows in points
move_row <- nrow(moves)

#turning od lines into route able points
moves <- cbind(moves %>% st_coordinates() %>% as.data.frame(),
               CrossingId = map(1:move_row, function(x){rep(moves$CrossingId[x],2)}) %>% unlist()
               ) %>% 
  mutate(L1 = rep(c("o","d"),move_row)) %>% 
  select(CrossingId, part = L1, X, Y) %>% 
  st_as_sf(coords = c("X", "Y"), crs = 4326)

#setting up avoid area polygons
avoid <- st_read("data/avoid_areas.shp") %>% 
  select(CrossingId) %>%
  filter(CrossingId %in% moves$CrossingId) %>% 
  st_transform(4326)

#function to run routes and test alt path
crossing_analysis <- function(x){
 print(x)
  o <- moves %>% filter(part == "o" & CrossingId == x)
  d <- moves %>% filter(part == "d" & CrossingId == x)
  b <- avoid %>% filter(CrossingId == x)
  
  org <- route(origin = o, 
               destination = d, 
               results = 1, 
               routing_mode = "fast", 
               transport_mode = "car", 
               traffic = FALSE)
  
  if (is.null(org)){print("no route")}else{org <- st_zm(org)}
  
  alt <- route(origin = o, 
               destination = d, 
               results = 1, 
               routing_mode = "fast", 
               transport_mode = "car", 
               traffic = FALSE,
               avoid_area = b)
  

  
  if (is.null(alt)){print("no route")}else{alt <- st_zm(alt)}
  
  if (is.null(org)){
    data.frame(CrossingId =NA, scenario =NA, rank = NA, distance = NA, duration = NA)
  }else{
    rbind(
      org %>% transmute(CrossingId = x, scenario = "base", rank, distance, duration),
      alt %>% transmute(CrossingId = x, scenario = "closure", rank, distance, duration)
    )  
  }
  
  
}

#run crossing analysis and collect results
#df <- map_df(unique(moves$CrossingId), crossing_analysis)

#df %>% st_write("data/results.shp")

df <- st_read("data/results.shp")

metrics_df <- df %>% 
  select(-rank) %>% 
  st_drop_geometry() %>% 
  group_by(CrossingId) %>% 
  pivot_wider(names_from = "scenario", values_from = c("distance","duration")) %>% 
  ungroup() %>% 
  left_join(moves_straight_distance) %>% 
  mutate(circuity_base = distance_base / eu_distance) %>% 
  mutate(circuity_closure = distance_closure / eu_distance) %>% 
  mutate(distance_change = distance_closure - distance_base) %>% 
  mutate(duration_change = duration_closure - duration_base) %>% 
  mutate(circuity_change = circuity_closure - circuity_base) %>% 
  mutate(circuity_pctchg = circuity_change / circuity_base) %>% 
  mutate(distance_pctchg = distance_change / distance_base) %>% 
  mutate(duration_pctchg = duration_change / duration_base)
  
metrics_df %>% 
  write_csv("data/metrics.csv")








